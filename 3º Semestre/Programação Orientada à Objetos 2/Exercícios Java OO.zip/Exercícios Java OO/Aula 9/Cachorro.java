
public class Cachorro extends Mamifero {
    
    String tamanho;
    String raca;

    @Override
    public String emitirSom() {
        return "Au au";
    }
    
}
