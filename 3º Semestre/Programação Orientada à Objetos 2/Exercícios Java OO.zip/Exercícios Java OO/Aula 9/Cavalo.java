public class Cavalo extends Mamifero {

    @Override
    public String emitirSom() {
        return "som do cavalo";
    }
    
}
