public abstract class Mamifero extends Animal {
    
    public String amamentar(){
        return "amamentando";
    }
    
}
