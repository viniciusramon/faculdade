public abstract class Ave extends Animal {
    
    public abstract String voar();
    
}
