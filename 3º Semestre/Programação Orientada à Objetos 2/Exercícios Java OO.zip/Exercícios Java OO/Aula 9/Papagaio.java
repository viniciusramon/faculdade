public class Papagaio extends Ave {

    @Override
    public String voar() {
        return "voando";
    }

    @Override
    public String emitirSom() {
        return "Loro quer biscoito";
    }
  
}
