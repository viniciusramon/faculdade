
public class AreaDoTriangulo {
	public static void main(String[] args) {
		// Entrada de dados
		int base = 10;
		int altura = 4;
		
		// Processamento
		int area = (base * altura)/2;
		
		// Sa�da
		System.out.println("A �rea do tri�ngulo �:" + area);
	}
	
}
