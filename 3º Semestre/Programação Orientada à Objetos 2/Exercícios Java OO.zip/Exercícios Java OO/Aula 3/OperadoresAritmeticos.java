
public class OperadoresAritmeticos{
    public static void main(String[] args){
        int x = 878;
        int y = 321;
        
        int adicao = x + y;
        System.out.println(x + " + " + y + " = " + adicao);

        int subtracao = x - y;
	    System.out.println(x + " - " + y + " = " + subtracao);

	    float divisao = (float) x / y;
	    System.out.println(x + " / " + y + " = " + divisao);

	    int multiplicacao = x * y;
	    System.out.println(x + " * " + y + " = " + multiplicacao);
	    }
	}

