
public class OperacoesCasting {
    public static void main(String[] args) {
    	
    	float div = (float) 1850/3;
	        
        
        System.out.println("> Sem utilizar Cast = " + div);
                
        System.out.println("> Utilizando Cast para int = " + ((int) div));
        
    }
	    
	}
