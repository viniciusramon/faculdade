//Exercício 5
public class Casting {
    public static void main(String[] args) {
        float a  = (float) 5.0;
        int b = (int) 5.1987;
        float c = 100;
        System.out.println(a + " " + b + " " + c);
    }
}
