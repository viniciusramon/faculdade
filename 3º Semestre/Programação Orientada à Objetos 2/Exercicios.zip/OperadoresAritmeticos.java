//Exercício 3
public class OperadoresAritmeticos {
    public static void main(String[] args) {
        int a = 10;
        int b = 15;
        int c = 3;
        int adicao = (a+b+c);
        int subtracao = (a-b-c);
        int multiplicacao = (a*b)*c;
        int divisao = (a+b)/c;
        System.out.println("Adição: "+ adicao);
        System.out.println("Subtração: "+ subtracao);
        System.out.println("Multiplicação: "+ multiplicacao);
        System.out.println("Divisão: "+ divisao);
    }
}
