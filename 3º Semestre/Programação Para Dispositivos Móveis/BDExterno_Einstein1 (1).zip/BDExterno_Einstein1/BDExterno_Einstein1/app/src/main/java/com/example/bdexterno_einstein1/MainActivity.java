package com.example.bdexterno_einstein1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements adaptadorArrayLista.ClickItem{

    // Executar o IPconfig conforme passo 17 de nosso tutorial de conexão com o BD externo.
    // Em caso de dúvidas sobre o motivo/causa/circustância de ter que executar este comando, assistir a
    // gravação da aula entre os minutos 00:14 e 00:23
    // IP DO COMPUTADOR DO BARRETO: 192.168.2.104
    String ipConexaoPHP = "192.168.2.104";

    //criar as variáveis que vão puxar os campos da tela de layout "activity_main.xml"
    EditText     txtNome, txtIdade;
    RecyclerView lista;
    String       idCadastro;

    // variáveis para montar a lista
    adaptadorArrayLista adaptador;
    ArrayList<baseArrayLista> arrayLista = new ArrayList<baseArrayLista>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ligar os IDs do R.id com as variáveis que vão puxar os campos da tela de layout
        txtNome    = findViewById(R.id.txtNome);
        txtIdade   = findViewById(R.id.txtIdade);
        lista      = findViewById(R.id.lista);
        idCadastro = "0";

        // Este código contém as permissões da tela para acesso a internet
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        preencheLista();
    }

    public void clickInserir(View v){
        try {
            // chamada o site PHP que irá inserir os dados no MYSQL para o APK
            URL site = new URL("http://"+ ipConexaoPHP + "/BDExterno_Einstein1/gravaDados.php" +
                    "?id="    + idCadastro +
                    "&nome="  + txtNome.getText().toString() +
                    "&idade=" + txtIdade.getText().toString() +
                    "&operacao=I");

            Log.e("Barreto", "http://"+ ipConexaoPHP + "/BDExterno_Einstein1/gravaDados.php" +
                    "?id="    + idCadastro +
                    "&nome="  + txtNome.getText().toString() +
                    "&idade=" + txtIdade.getText().toString() +
                    "&operacao=I");

            // abrir a conexão com o site
            HttpURLConnection conexao = (HttpURLConnection) site.openConnection();

            // de fato, conectar o site
            conexao.connect();

            // ler a página - assim força o PHP a executar a página
            InputStream entradaDados = conexao.getInputStream();

            preencheLista();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void clickAlterar(View v){

    }

    public void clickExcluir(View v){

    }

    public void clickLimpar(View v){

    }

    public void preencheLista(){
        try {
            // chamada o site PHP que irá inserir os dados no MYSQL para o APK
            URL site = new URL("http://" + ipConexaoPHP + "/BDExterno_Einstein1/buscaDados.php");

            // abrir a conexão com o site
            HttpURLConnection conexao = (HttpURLConnection) site.openConnection();

            // pegar os dados que foram escritos na página pelo PHP (pegar os dados do JSON)
            InputStream entradaDados = conexao.getInputStream();

            // ler os dados que foram pegos
            BufferedReader leitor = new BufferedReader(new InputStreamReader(entradaDados));

            // os dados estarão em listas de chave/valor. Precisamos "decodificar" isto para conseguirmos lê-los
            String linha;
            StringBuilder decodificador = new StringBuilder();

            // ler os dados usando nosso "decodificador"
            while((linha = leitor.readLine()) != null){
                // acrescentando nossa linha lida em nosso "decodificador"
                decodificador.append(linha);
            }

            // pegar os dados "decodificados" em linha e vamos transformar num objeto possível de ser lido pelo
            // Java do Android Studio
            String stringJSON = decodificador.toString();

            // vou transformar o que li novamente em JSON para ser trabalhado
            JSONArray saidaJson = new JSONArray(stringJSON);

            // limpar o arrayLista
            arrayLista = new ArrayList<baseArrayLista>();

            // monta o cabeçalho de nosso recyclerView (nossa lista)
            baseArrayLista cabecalho = new baseArrayLista();
            cabecalho.id    = "ID";
            cabecalho.nome  = "Nome";
            cabecalho.idade = "Idade";
            arrayLista.add(cabecalho);

            // montar as linhas do recyclerView (nossa lista)
            for (int cont = 0; cont < saidaJson.length(); cont++){
                // transforma nosso arrayJson num objeto passível de manipulação
                JSONObject linhaJson = saidaJson.getJSONObject(cont);

                // colocar a linha do Json no nosso array
                baseArrayLista registro = new baseArrayLista();
                registro.id    = linhaJson.getString("id");
                registro.nome  = linhaJson.getString("nome");
                registro.idade = linhaJson.getString("idade");
                arrayLista.add(registro);
            }

            // configurar nosso RecyclerView
            lista.setLayoutManager(new LinearLayoutManager(this));

            // configurar o adaptador
            // o adaptador adapta o array para o formato da lista de nosso RecyclerView
            adaptador = new adaptadorArrayLista(this, arrayLista);
            adaptador.setClickListener(this);

            // coloco o adaptador (já adaptado) para o RecyclerView
            lista.setAdapter(adaptador);

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemClick(View v, int position) {
        // posição 0 é o cabeçalho
        if (position > 0){
            // preenche os campos com os valores do item clicado
            idCadastro = arrayLista.get(position).id;
            txtNome.setText(arrayLista.get(position).nome);
            txtIdade.setText(arrayLista.get(position).idade);
        }
    }
}
