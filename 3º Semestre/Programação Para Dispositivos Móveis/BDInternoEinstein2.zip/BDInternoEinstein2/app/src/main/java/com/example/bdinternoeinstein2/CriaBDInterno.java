package com.example.bdinternoeinstein2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CriaBDInterno extends SQLiteOpenHelper {

    // esta variável estática controla a execução do método onUpgrade. Cada vez que se aumenta o valor desta
    //   variável, executa-se o método onUpgrade.
    private static int VERSAO = 1;

    // O construtor sugerido era muito grande, foi refeito o construtor com apenas 1 parâmetro
    public CriaBDInterno(Context contexto){
        // Contexto, nome BD, padrão, versão para chamada do onUpgrade
        super(contexto, "listaSuper.bd", null, VERSAO);
    }

    // Quando se instala o APK, executa-se o método onCreate.
    // Quando se aumenta o valor da variável VERSAO, executa-se o método onUpgrade

    @Override
    public void onCreate(SQLiteDatabase db) {
        // comando SQL que será executado na função db.ExecSQL.
        String comandoSQL = "CREATE TABLE listaSuper(" +
                             "   _id             INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
                             "   nomeProduto     VARCHAR(50), " +
                             "   valorUnProduto  FLOAT," +
                             "   qtdeProduto     INTEGER)";
        db.execSQL(comandoSQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // é executado quando se aumenta o valor da variável VERSAO
        db.execSQL("DROP TABLE IF EXISTS listaSuper");
        this.onCreate(db);
    }
}
