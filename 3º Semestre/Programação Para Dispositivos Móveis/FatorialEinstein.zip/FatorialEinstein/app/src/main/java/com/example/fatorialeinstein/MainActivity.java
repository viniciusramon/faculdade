package com.example.fatorialeinstein;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Layout (arquivo.xml) é um arquivo XML que possui as informações de uma tela (visual) do APK
    // Código-fonte (arquivo.java) é um arquivo que contem a parte de regra de negócio (programação) do APK
    // Activity (junção do XML e do Java) é uma tela completa (código + layout) da APK.
    //     Uma activity precisa ser declarada no AndroidManifest.xml para funcionar.

    // por padrão, é criado o método OnCreate
    // OnCreate: é executado no momento de criação (primeira execução) da tela da APK.

    // puxando os componentes de tela (XML) para a parte de programação (Java)
    EditText txtNumero;
    Button   btnCalcular;
    TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // chamada do construtor da classe pai (AppCompatActivity)
        super.onCreate(savedInstanceState);
        // setContextView: liga o layout XML na classe Java
        setContentView(R.layout.activity_main);

        // ligar a instância de EditText e Button aos componentes de tela (R.id)
        txtNumero    = findViewById(R.id.txtNumero);
        btnCalcular  = findViewById(R.id.btnCalcular);
        txtResultado = findViewById(R.id.txtResultado);
    }

    // o método que é chamado no onClick PRECISA ser PUBLIC!!!
    // Porque o XML não está na mesma package (pasta) do Java
    // o View v é porque os componentes visuais do XML sempre passam um parâmetro/argumento View
    //   para poder identificar qual componente chamou aquele método
    public void fatorial(View v){
        String txtNumero_text = txtNumero.getText().toString();
        int numeroFat         = Integer.valueOf(txtNumero_text);

        // fatorial deve começar em 1, porque se começar em 0 (padrão), ele vai multiplicar por 0 e
        //   independente do valor, valor*0 é sempre igual a 0.
        // Já o 1, independente do valor, ele vai começar o fatorial pelo número que você digitou:
        //   1000000 * 1 = 1000000
        long fatorial = 1;
        int  contador;

        // ele começa pelo valor que você digitou para fatorar. ex: se digitou 20, ele começa por 20.
        for(contador = numeroFat; contador > 0; contador--){
            // depois, ele pega o valor da var fatorial e multiplica pelo contador:
            //  ex: fatorial começa em 1. 1* 20 (numero digitado) = 20
            //  ex: fatorial = 20 * contador-- (19) = 380
            //  ex: fatorial = 380 * contador-- (18) = 6840
            //  ex: fatorial = 6840 * contador-- (17) = ?
            //  ex: fatorial = ? * 1 = resultado final
            fatorial = fatorial * contador;
        }

        // Quando você for criar um Toast, digite Toa e selecione a opção Create a New Toast, pois ele
        //    coloca todos os parâmetros automaticamente para você.
        Toast.makeText(this, "O fatorial de " + txtNumero_text + " é: " + fatorial,
                Toast.LENGTH_SHORT).show();

        txtResultado.setText("O fatorial de " + txtNumero_text + " é: " + fatorial);
    }
}
