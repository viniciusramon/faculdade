package com.example.geniuseinstein;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    // Botões da tela
    Button btnComecar, btnVerde, btnVermelho, btnAmarelo, btnAzul;
    // lista que contem a sequencia de botões para piscar no jogo
    List<Integer> listaPiscaBotao = new ArrayList<Integer>();
    // posição da listaPiscaBotao
    int posicaoListaPiscaBotao;
    // gera o barulhinho de cada botão do Genius
    ToneGenerator geradorSom = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnComecar  = findViewById(R.id.btnComecar);
        btnVerde    = findViewById(R.id.btnVerde);
        btnVermelho = findViewById(R.id.btnVermelho);
        btnAmarelo  = findViewById(R.id.btnAmarelo);
        btnAzul     = findViewById(R.id.btnAzul);

        iniciar();
    }

    public void iniciar(){
        // limpar/iniciar o listaPiscaBotao
        listaPiscaBotao.clear();

        //zerar posicaoListaPiscaBotao
        posicaoListaPiscaBotao = 0;

        // habilita o começar, desabilita os demais
        btnComecar.setEnabled(true);
        btnVerde.setEnabled(false);
        btnVermelho.setEnabled(false);
        btnAmarelo.setEnabled(false);
        btnAzul.setEnabled(false);

        // troco a cor do btnComecar
        btnComecar.setBackgroundColor(Color.parseColor("#9C27B0"));
    }

    public void clickComecar(View v){
        btnComecar.setEnabled(false);
        btnComecar.setBackgroundColor(Color.parseColor("#509C27B0"));

        sortearBotao();
    }

    public void sortearBotao(){
        // sortear uma cor de  botão
        Random sorteador  = new Random();
        int botaoSorteado = sorteador.nextInt(4);

        // após sortear, adicionar no listaPiscaBotao
        listaPiscaBotao.add(botaoSorteado);

        //cada vez que chegar ao final do listaPiscaBotao, recomeça a lista dos cliques
        posicaoListaPiscaBotao = 0;

        // timer para piscar os botões durante a apresentação da lista da jogada
        new CountDownTimer(listaPiscaBotao.size() * 750, 250){

            // passada que conta quantas vezes passou pelo onTick (limite 3, que é 750/250)
            int passada = 0;
            //  quantas vezes já piscou o botão na tela
            int contPiscadas;

            // onTick: a cada passada do countDownInterval (no nosso caso, a cada 250ms), ele
            // executará esta função.
            @Override
            public void onTick(long millisUntilFinished) {
                // passada 0 e 1 = acende o botão
                // passada 2 = apaga o botão
                if(passada < 2){
                    if(listaPiscaBotao.get(contPiscadas) == 0){
                        btnVerde.setBackgroundColor(Color.parseColor("#5000FF00"));
                        geradorSom.startTone(ToneGenerator.TONE_CDMA_ABBR_ALERT, 250);
                    }else if(listaPiscaBotao.get(contPiscadas) == 1){
                        btnVermelho.setBackgroundColor(Color.parseColor("#50FF0000"));
                        geradorSom.startTone(ToneGenerator.TONE_CDMA_ANSWER, 250);
                    }else if(listaPiscaBotao.get(contPiscadas) == 2){
                        btnAmarelo.setBackgroundColor(Color.parseColor("#50FFFF00"));
                        geradorSom.startTone(ToneGenerator.TONE_CDMA_ABBR_INTERCEPT, 250);
                    }else{
                        btnAzul.setBackgroundColor(Color.parseColor("#500000FF"));
                        geradorSom.startTone(ToneGenerator.TONE_CDMA_ABBR_REORDER, 250);
                    }

                    passada++;
                }else{
                    // para de piscar e vai para o próximo botão
                    passada = 0;
                    contPiscadas++;

                    btnVerde.setBackgroundColor(Color.parseColor("#00FF00"));
                    btnVermelho.setBackgroundColor(Color.parseColor("#FF0000"));
                    btnAmarelo.setBackgroundColor(Color.parseColor("#FFFF00"));
                    btnAzul.setBackgroundColor(Color.parseColor("#0000FF"));
                }
            }

            // ao finalizar o tempo (no nosso caso, listaPiscaBotao.size() * 750), ele passará 1x aqui
            @Override
            public void onFinish() {

            }
        }.start();

        btnVerde.setEnabled(true);
        btnVermelho.setEnabled(true);
        btnAmarelo.setEnabled(true);
        btnAzul.setEnabled(true);
    }

    public void clickCor(View v) {
        // contem o botão que foi clicado, convertido para 0 a 3
        final int botaoSelecionado;

        if(v.getId() == R.id.btnVerde){
            botaoSelecionado = 0;
        }else if(v.getId() == R.id.btnVermelho){
            botaoSelecionado = 1;
        }else if(v.getId() == R.id.btnAmarelo){
            botaoSelecionado = 2;
        }else{
            botaoSelecionado = 3;
        }

        new CountDownTimer(250, 250){

            @Override
            public void onTick(long millisUntilFinished) {
                if(botaoSelecionado == 0){
                    btnVerde.setBackgroundColor(Color.parseColor("#5000FF00"));
                    geradorSom.startTone(ToneGenerator.TONE_CDMA_ABBR_ALERT, 250);
                }else if(botaoSelecionado == 1){
                    btnVermelho.setBackgroundColor(Color.parseColor("#50FF0000"));
                    geradorSom.startTone(ToneGenerator.TONE_CDMA_ANSWER);
                }else if(botaoSelecionado == 2){
                    btnAmarelo.setBackgroundColor(Color.parseColor("#50FFFF00"));
                    geradorSom.startTone(ToneGenerator.TONE_CDMA_ABBR_INTERCEPT);
                }else{
                    btnAzul.setBackgroundColor(Color.parseColor("#500000FF"));
                    geradorSom.startTone(ToneGenerator.TONE_CDMA_ABBR_REORDER);
                }
            }

            @Override
            public void onFinish() {
                btnVerde.setBackgroundColor(Color.parseColor("#00FF00"));
                btnVermelho.setBackgroundColor(Color.parseColor("#FF0000"));
                btnAmarelo.setBackgroundColor(Color.parseColor("#FFFF00"));
                btnAzul.setBackgroundColor(Color.parseColor("#0000FF"));
            }
        }.start();

        if(listaPiscaBotao.get(posicaoListaPiscaBotao) == botaoSelecionado){
            posicaoListaPiscaBotao++;
            if(posicaoListaPiscaBotao >= listaPiscaBotao.size()){
                btnVerde.setEnabled(false);
                btnVermelho.setEnabled(false);
                btnAmarelo.setEnabled(false);
                btnAzul.setEnabled(false);

                new CountDownTimer(500,500){

                    @Override
                    public void onTick(long millisUntilFinished) {

                    }

                    @Override
                    public void onFinish() {
                        sortearBotao();
                    }
                }.start();
            }
        }else{
            Toast.makeText(this,
                    "ERROU!!! Você chegou no nível " + listaPiscaBotao.size(),
                    Toast.LENGTH_SHORT).show();
            iniciar();
        }
    }
}