package com.example.bdinternoeinstein;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CriaBDInterno extends SQLiteOpenHelper {

    // esta variável é responsável por ditar a versão do DDL do SQL.
    // SE NÃO existir o arquivo citado no construtor da classe SQLiteOpenHelper
    //    que neste caso é o arquivo "notas.BD", ele executará o método onCreate
    // SE existir o arquivo citado no construtor da classe SQLiteOpenHelper que neste caso é o arquivo "notas.BD"
    //    && a variável versão for alterada, então ele executará o método onUpgrade.
    private static int VERSAO = 1;

    // Context é uma instância de classe utilizada para passar o ponto o ponto atual
    //    de sua aplicação
    public CriaBDInterno(Context contexto){
        super(contexto, "notas.BD", null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String comandoSQL = "CREATE TABLE notas(" +
                            "   _id  INT NOT NULL PRIMARY KEY AUTOINCREMENT, " +
                            "   nome VARCHAR(50), " +
                            "   nota INT);";
        // o comando para executar uma instrução SQL é o db.execSQL(string)
        db.execSQL(comandoSQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS notas");
        this.onCreate(db);
    }
}
