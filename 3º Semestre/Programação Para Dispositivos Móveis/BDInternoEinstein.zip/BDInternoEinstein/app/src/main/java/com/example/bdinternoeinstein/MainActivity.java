package com.example.bdinternoeinstein;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    // .java é o nosso arquivo de classe (programa)
    // .xml é o nosso arquivo de layout (desenha)
    // juntar um .java e um .xml gera uma activity

    // puxar os componentes visuais da tela para a programação
    EditText txtNome, txtNota;
    ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // para ligar nossas instâncias ("variáveis") aos componentes da tela, utiliza-se o comando
        // findViewById(), usando a propriedade id dos componentes de tela, setada no arquivo R.id
        txtNome = findViewById(R.id.txtNome);
        txtNota = findViewById(R.id.txtNota);
        lista   = findViewById(R.id.lista);
    }

    // este parâmetro (View v) serve para identificar qual componente visual que chamou este método
    public void clickGravar(View v){
        // todos componentes de tela herdam propriedades da classe view, por isto, para
        // generalizar os componentes de tela, usamos uma instância de View

        // para chamar a base de dados, usamos uma instância de SQLiteDatabase
        SQLiteDatabase bd;
        Long resultInsert;

        // para passar um pseudo-array (tipo de array criado dinamicamente), usaremos
        // ContentValues -> container de dados
        ContentValues linhaInsercao = new ContentValues();

        CriaBDInterno meuBanco = new CriaBDInterno(getBaseContext());
        // este comando abre o BD para a gravação
        bd = meuBanco.getWritableDatabase();

        // colocar meus dados no container de dados
        linhaInsercao.put("nome", txtNome.getText().toString());
        linhaInsercao.put("nota", txtNota.getText().toString());

        // vou de fato inserir os dados no BD
        // primeiro é o  nome da tabela, depois o padrão/factory, depois os dados
        resultInsert = bd.insert("notas", null, linhaInsercao);

    }
}
