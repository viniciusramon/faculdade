package com.example.mediaseinstein;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    EditText txtNome, txtNota;
    TextView txtLista;
    Button   btnAdicionar, btnCalcular;
    float    somaNota, qtdeNota, media;
    List<Float> listaNota = new ArrayList<Float>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNome      = findViewById(R.id.txtNome);
        txtNota      = findViewById(R.id.txtNota);
        txtLista     = findViewById(R.id.txtLista);
        btnAdicionar = findViewById(R.id.btnAdicionar);
        btnCalcular  = findViewById(R.id.btnCalcular);
        somaNota     = 0;
        qtdeNota     = 0;
    }

    public void clickAdicionar(View v){
        txtLista.setText(txtLista.getText().toString() + " " + txtNota.getText());
        // somaNota = somaNota + Float.valueOf(txtNota.getText())

        somaNota += Float.valueOf(txtNota.getText().toString());
        qtdeNota++;

        listaNota.add(Float.valueOf(txtNota.getText().toString()));

        txtNota.setText("");
    }

    public void clickCalcular(View v){
        media = somaNota / qtdeNota;
        Toast.makeText(
                this, "VAR - A média é: " + media, Toast.LENGTH_SHORT).show();

        int contador;
        media = 0;
        for(contador = 0; contador < listaNota.size(); contador++){
            media = media + listaNota.get(contador);
        }
        media = media / listaNota.size();
        Toast.makeText(this, "ARRAY - A média é: " + media, Toast.LENGTH_SHORT).show();
    }

}
