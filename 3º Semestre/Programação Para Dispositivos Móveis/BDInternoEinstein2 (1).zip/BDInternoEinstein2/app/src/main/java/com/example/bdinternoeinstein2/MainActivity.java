package com.example.bdinternoeinstein2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Classe.java = Arquivo que contem a parte de programação de regras do software / funcionalidades.
    // Layout.xml  = Arquivo que contém o layout das telas que o usuário usará no aplicativo.
    // Activity    = Conjunto de layout + classe de uma determinada tela de usuário.

    // Para instânciar os elementos de tela, verificar o tipo de cada elemento
    EditText txtNomeProduto, txtQtdeProduto, txtValorUnProduto;
    ListView lista;

    int idProduto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // O comando findViewById busca no arquivo R.id o ID dos elementos de tela
        txtNomeProduto    = findViewById(R.id.txtNomeProduto);
        txtQtdeProduto    = findViewById(R.id.txtQtdeProduto);
        txtValorUnProduto = findViewById(R.id.txtValorUnProduto);

        lista             = findViewById(R.id.lista);

        idProduto = 0;

        preencheLista();
    }

    public void preencheLista(){
        // Cursor = tipo de array que possui o retorno de um select de um BD
        final Cursor resultadoSelect;
        // array com os nomes dos campos da tabela do BD
        String camposBD[]  = {"_id", "nomeProduto", "valorUnProduto", "qtdeProduto"};
        // array com os campos de nosso layout criado no arquivo layout_lista.xml
        int camposLayout[] = {R.id.txtLayoutId, R.id.txtLayoutNome, R.id.txtLayoutValorUn, R.id.txtLayoutQtde};

        // seleção no BD
        SQLiteDatabase banco;
        CriaBDInterno meuBanco = new CriaBDInterno(getApplicationContext());
        // abrir o BD para leitura
        banco = meuBanco.getReadableDatabase();

        resultadoSelect = banco.query("listaSuper", camposBD, null, null,
                null, null, null);

        // se tiver dados no cursor, você deverá mover o leitor para o início do cursor, pois o cursor
        //   parou no final dele na query acima
        if(resultadoSelect != null) {
            resultadoSelect.moveToFirst();
        }
        // fechei o bd
        banco.close();

        // colocar os valores usando um adaptador na listView lista
        SimpleCursorAdapter adaptador = new SimpleCursorAdapter(getApplicationContext(),
                R.layout.layout_lista, resultadoSelect, camposBD, camposLayout, 0);

        lista.setAdapter(adaptador);

        // Clique em cada item da lista
        lista.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        // position OU i é a linha que você clicou
                        int contadorLinha = 0;
                        for(resultadoSelect.moveToFirst(); !resultadoSelect.isAfterLast();
                            resultadoSelect.moveToNext()){
                            if(contadorLinha == position){
                                // setText coloca texto num editText
                                txtNomeProduto.setText(resultadoSelect.getString(1));
                                txtValorUnProduto.setText(resultadoSelect.getString(2));
                                txtQtdeProduto.setText(resultadoSelect.getString(3));

                                idProduto = resultadoSelect.getInt(0);
                            }
                            // para seguir para o próximo índice do Cursor
                            contadorLinha++;
                        }
                    }
                }
        );

    }

    // este parâmetro View v serve para identificar qual elemento de tela (View) que chamou o método
    public void clickInserir(View v){
        if(idProduto == 0) {
            // mostrará o resultado da inserção
            long resultadoInsert;

            // container/array de dados contendo os dados que irão para a gravação
            ContentValues dadosInsercao = new ContentValues();

            // conexão com o BD
            SQLiteDatabase banco;
            CriaBDInterno meuBanco = new CriaBDInterno(getApplicationContext());
            // abre o banco para escrita de dados
            banco = meuBanco.getWritableDatabase();

            // inserir os dados no container de dados que passará os dados para o comando de inserção
            dadosInsercao.put("nomeProduto", txtNomeProduto.getText().toString());
            dadosInsercao.put("valorUnProduto", txtValorUnProduto.getText().toString());
            dadosInsercao.put("qtdeProduto", txtQtdeProduto.getText().toString());

            // executar o comando de inserção
            resultadoInsert = banco.insert("listaSuper", null, dadosInsercao);

            if (resultadoInsert == -1) {
                Toast.makeText(this, "Erro ao inserir!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Inserido com sucesso!", Toast.LENGTH_SHORT).show();
            }
            preencheLista();
        }else{
            Toast.makeText(this,
                    "Existe um ID carregado! Limpe o formulário antes de prosseguir!",
                    Toast.LENGTH_SHORT).show();
        }
    }

    public void clickAlterar(View v){
        if(idProduto > 0) {
            long resultadoUpdate;

            // Container de dados contendo a ligação chave=>valor com os camposBD=>novosValores
            ContentValues dadosAlteracao = new ContentValues();

            // criar a instância para alteração do BD
            SQLiteDatabase banco;
            CriaBDInterno meuBanco = new CriaBDInterno(getApplicationContext());
            banco = meuBanco.getWritableDatabase();

            dadosAlteracao.put("nomeProduto", txtNomeProduto.getText().toString());
            dadosAlteracao.put("valorUnProduto", txtValorUnProduto.getText().toString());
            dadosAlteracao.put("qtdeProduto", txtQtdeProduto.getText().toString());

            // de fato executar o update
            resultadoUpdate = banco.update("listaSuper", dadosAlteracao,
                    "_id = " + idProduto, null);

            // verifica se deu erro ou não
            if (resultadoUpdate == -1) {
                Toast.makeText(this, "Erro ao alterar!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Alterado com sucesso!", Toast.LENGTH_SHORT).show();
            }
            preencheLista();
        }else{
            Toast.makeText(this,
                    "Selecione a linha a ser alterada!",
                    Toast.LENGTH_SHORT).show();
        }
    }

    public void clickExcluir(View v){
        if(idProduto > 0) {
            // variável que armazena se deu certo ou não a exclusão
            long resultadoDelete;

            // criar uma instância para manipular meu BD
            SQLiteDatabase banco;
            CriaBDInterno meuBanco = new CriaBDInterno(getApplicationContext());
            banco = meuBanco.getWritableDatabase();

            // comando para executar a exclusão
            resultadoDelete = banco.delete("listaSuper", "_id = " + idProduto, null);

            if (resultadoDelete == -1) {
                Toast.makeText(this, "Erro ao excluir!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Excluído com sucesso!", Toast.LENGTH_SHORT).show();
            }
            preencheLista();
        }else{
            Toast.makeText(this,
                    "Selecione a linha a ser excluída!",
                    Toast.LENGTH_SHORT).show();
        }
    }

    public void clickLimpar(View v){
        idProduto = 0;
        txtNomeProduto.setText("");
        txtQtdeProduto.setText("");
        txtValorUnProduto.setText("");
    }
}

