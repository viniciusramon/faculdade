package com.example.bdexterno_einstein1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adaptadorArrayLista extends RecyclerView.Adapter<adaptadorArrayLista.ViewHolder>{

    private ArrayList<baseArrayLista> listaNomes;
    // este LayoutInflater é quem vai mostrar o layout no RecyclerView
    private LayoutInflater layout;
    private ClickItem eventoClick;

    public adaptadorArrayLista(Context contextoC, ArrayList<baseArrayLista> listaNomesC){
        this.layout     = LayoutInflater.from(contextoC);
        this.listaNomes = listaNomesC;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // código para colocar o layout na tela (RecyclerView)
        View tela = layout.inflate(R.layout.lista_layout, parent, false);
        return new ViewHolder(tela);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        // faz o preenchimento dos campos do layout com a informação que vem no ArrayList
        holder.txtLayoutId.setText(   listaNomes.get(position).id);
        holder.txtLayoutNome.setText( listaNomes.get(position).nome);
        holder.txtLayoutIdade.setText(listaNomes.get(position).idade);
    }

    @Override
    public int getItemCount() {
        return listaNomes.size();
    }

    // criação da interface de manipulação do layout
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        // puxar os campos que estão no layout
        TextView txtLayoutId, txtLayoutNome, txtLayoutIdade;

        // criação do construtor da classe ViewHolder
        public ViewHolder(View v){
            // super é a chamada do construtor da classe pai
            super(v);
            // vamos puxar os campos do layout
            txtLayoutId    = v.findViewById(R.id.txtLayoutId);
            txtLayoutNome  = v.findViewById(R.id.txtLayoutNome);
            txtLayoutIdade = v.findViewById(R.id.txtLayoutIdade);

            //colocar o click em cada linha de nosso RecyclerView
            v.setOnClickListener(this);
        }

        // fazer a ação do OnClick
        public void onClick(View v){
            // se o evento de onClick não for null
            if(eventoClick != null)
                eventoClick.onItemClick(v, getBindingAdapterPosition());
            // se der errado, usar o getAdapterPosition()
        }

    }

    // código para pegar os itens
    String getItem(int posicao){
        return listaNomes.get(posicao).id;
    }

    // código para fazer o OnClickListener, que aguardará o click da loinha do RecyclerView
    void setClickListener(ClickItem clickDoItem){
        this.eventoClick = clickDoItem;
    }

    // esta interface nos ajudará a identificar qual foi a linha clicada no RecyclerView
    public interface ClickItem{
        void onItemClick(View v, int position);
    }
}
