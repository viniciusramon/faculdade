package com.example.bdexterno_einstein1;

public class baseArrayLista {
    public String id, nome, idade;
}
