package com.example.adivinheeinstein;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    TextView txtNumeroTentativas, txtTentativasAnteriores;
    EditText txtTentativa;
    int      numeroSorteado, numeroTentativas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNumeroTentativas     = findViewById(R.id.txtNumeroTentativas);
        txtTentativa            = findViewById(R.id.txtTentativa);
        txtTentativasAnteriores = findViewById(R.id.txtTentativasAnteriores);
    }

    public void clickNovo(View v){
        Random sorteador = new Random();
        numeroSorteado   = sorteador.nextInt(100);
        numeroTentativas = 10;
        txtNumeroTentativas.setText("Tentativas: 10");
        txtTentativa.setText("");
        txtTentativasAnteriores.setText("Tentativas Anteriores: ");
    }

    public void clickTentar(View v){
        if(numeroTentativas <= 0){
            Toast.makeText(this, "Acabou as tentativas!!!", Toast.LENGTH_SHORT).show();
            clickNovo(v);
        }else {
            int tentativaDigitada = Integer.valueOf(txtTentativa.getText().toString());

            if (tentativaDigitada == numeroSorteado) {
                Toast.makeText(this,
                        "Parabéns! Você acertou com " + (10 - numeroTentativas) + " tentativas.",
                        Toast.LENGTH_SHORT).show();
                clickNovo(v);
            }else if ((tentativaDigitada >= numeroSorteado-10) && (tentativaDigitada < numeroSorteado)) {
                Toast.makeText(this,
                        "QUASE LÁ!!! O número digitado é INFERIOR ao sorteado!",
                        Toast.LENGTH_SHORT).show();
                numeroTentativas--;
                txtNumeroTentativas.setText("Tentativas: " + numeroTentativas);
                txtTentativasAnteriores.setText(
                        txtTentativasAnteriores.getText().toString() + tentativaDigitada + " - ");
            }else if ((tentativaDigitada > numeroSorteado) && (tentativaDigitada <= numeroSorteado+10)){
                Toast.makeText(this,
                        "QUASE LÁ!!! O número digitado é SUPERIOR ao sorteado!",
                        Toast.LENGTH_SHORT).show();
                numeroTentativas--;
                txtNumeroTentativas.setText("Tentativas: " + numeroTentativas);
                txtTentativasAnteriores.setText(
                        txtTentativasAnteriores.getText().toString() + tentativaDigitada + " - ");
            }else if (tentativaDigitada < numeroSorteado) {
                Toast.makeText(this,
                        "O número digitado é INFERIOR ao sorteado!",
                        Toast.LENGTH_SHORT).show();
                numeroTentativas--;
                txtNumeroTentativas.setText("Tentativas: " + numeroTentativas);
                txtTentativasAnteriores.setText(
                        txtTentativasAnteriores.getText().toString() + tentativaDigitada + " - ");
            } else if (tentativaDigitada > numeroSorteado) {
                Toast.makeText(this,
                        "O número digitado é SUPERIOR ao sorteado!",
                        Toast.LENGTH_SHORT).show();
                numeroTentativas--;
                txtNumeroTentativas.setText("Tentativas: " + numeroTentativas);
                txtTentativasAnteriores.setText(
                        txtTentativasAnteriores.getText().toString() + tentativaDigitada + " - ");
            }
        }
    }
}
