<?php
$var = "Walace";
$VAR = "Soares";
echo "$var $VAR";
?>