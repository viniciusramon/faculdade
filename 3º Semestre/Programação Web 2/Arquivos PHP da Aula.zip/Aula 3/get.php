<?php
echo 'Hello ' . htmlspecialchars($_GET["name"]) . '!';
?>
