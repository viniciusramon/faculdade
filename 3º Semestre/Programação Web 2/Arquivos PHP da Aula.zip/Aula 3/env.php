<?php
echo 'My username is ' .$_ENV["USER"] . '!';
?>