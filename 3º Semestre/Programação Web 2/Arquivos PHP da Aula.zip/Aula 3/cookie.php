<?php 
echo $_COOKIE["CookieTeste"];
?>