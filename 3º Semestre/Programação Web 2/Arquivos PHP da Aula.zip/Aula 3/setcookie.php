<?php
$value = 'setando um cookie';
setcookie("CookieTeste", $value);
echo "Cookie setado!"
?>