<?php
$valor = 10;
function dobro(){
	$valor = 6;
	$valor = $valor * 2;
	echo "valor função dobro: ".$valor."<br>";
}
echo "valor: ".$valor."<br>";
dobro();
$valor = $valor * 10;
echo "valor: ".$valor."<br>";
?>
