<?php 
$valor = TRUE; 
($valor==TRUE) ? echo "Verdadeiro" : echo " Falso"; // Não funciona 
($valor==TRUE) ? print "Verdadeiro" : print " Falso"; // funciona
?>
