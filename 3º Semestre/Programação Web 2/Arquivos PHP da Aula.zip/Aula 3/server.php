<?php 
echo $_SERVER['SERVER_NAME'];
?>
