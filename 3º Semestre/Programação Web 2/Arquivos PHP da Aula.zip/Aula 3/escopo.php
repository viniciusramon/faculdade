<?php
$valor=10;
function dobro(){
	$valor = 6;
	$valor = $valor * 2;
	echo "\$valor ". $valor;
}
echo "\$valor = " .$valor;
dobro();
echo "\$valor = " .$valor;
?>