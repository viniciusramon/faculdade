<?php
define ("DADOS", 10);
define ("CARRO","Corsa",True);
echo "Carro = " . carro . "<br>"; //ou Carro ou CARRO
echo "Dados = " . DADOS . "<br>";
echo "DADOS = " . Dados . "<br>"; // Não funciona
?>