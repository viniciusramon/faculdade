<?php
$name = $_POST['username']; 
$email = $_POST['email'];  
echo "$name";
echo "$email";
?>  
