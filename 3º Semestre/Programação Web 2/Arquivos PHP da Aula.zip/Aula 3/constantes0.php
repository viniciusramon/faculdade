<?php 
define ("VALOR",10);
define ("FRUTA", "Manga",True);
echo "Fruta: " .Fruta;
echo "Valor: " .VALOR; 
?>