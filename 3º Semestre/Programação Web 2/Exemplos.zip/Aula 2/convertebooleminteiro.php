
<?php 
$a = TRUE;
$i = (int) $a;
echo '$i=' . $i . "<br>";
$a = FALSE;
$i = (int)$a;
echo '$i=' . $i ;
?>
   
