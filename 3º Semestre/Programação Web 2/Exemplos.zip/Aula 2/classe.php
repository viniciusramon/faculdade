<?php

class novaClasse{
	function imprime(){
		echo "Este é um objeto da classe novaClasse";
	}
}

$var = new novaClasse();
$var -> imprime();
?>