
<?php 
$a = "10"; 
$i = (int) $a; // $i será igual ao número 10;
echo "Valor de a: $a " . gettype($a);
echo "Valor de i: $i " . gettype($i);
?>
