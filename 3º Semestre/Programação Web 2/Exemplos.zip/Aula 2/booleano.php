<?php 
$s = True; // Verdadeiro 
$f = False; // Falso 
if($s==TRUE) {
echo "Verdadeiro";
} if($f) {
echo "\$f é Verdadeiro";
} else {
echo "Falso";
}
?>

