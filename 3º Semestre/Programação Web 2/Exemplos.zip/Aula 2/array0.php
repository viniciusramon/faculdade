
<?php 
$a = array("João", "Maria", "Pedro"); 
//unset($a[1]);
echo "<pre>";
print_r($a); 
echo "</pre>";
?>
