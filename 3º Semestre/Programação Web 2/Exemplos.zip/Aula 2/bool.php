<?php
$s = true;
$f = false;
if($s){
	echo "verdadeiro"."<br>";
}
if($f){
	echo "$f é verdadeiro"."<br>";
}
else{
	echo "falso"."<br>";
}

?>