<?php 
$n = 125 / 3; 
var_dump($n); 
var_dump((int) $n); 
var_dump(round($n)); 
?>
