<?php
$numero = 2147483647678899999;
echo "numero: ".$numero. " tipo: ".gettype($numero)."<br>";
$numero2 = $numero * 1000;
echo "numero2: ".$numero2. " tipo: ".gettype($numero2)."<br>";
$numero3 = 10000000000000000000000000;
var_dump($numero*$numero3);
?>