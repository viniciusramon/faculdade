
<?php 
$f1 = 1.25; 
$f2 = 1.7; 
$f3 = -2.55;
echo (int) $f1 . "<br>";
echo (int) $f2 . "<br>";
echo (int) $f3 . "<br>";
?>
    
