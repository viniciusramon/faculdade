
<?php 
$str = <<<'EOD' 
Exemplo de Texto 
Com multiplas linhas 
utilizando o novo padrão NowDoc. 
EOD;
echo $str;
?>
