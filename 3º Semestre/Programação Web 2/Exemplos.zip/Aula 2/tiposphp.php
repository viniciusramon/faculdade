<?php
$i = 10;
$nome = "Thiago";
$verdadeiro = true;
$valor = 100.50;
echo "i: ".$i." do tipo ".gettype($i)."<br>";
echo "nome: ".$nome." do tipo ".gettype($nome)."<br>";
echo "verdadeiro: ".$verdadeiro." do tipo ".gettype($verdadeiro)."<br>";
echo "valor: ".$valor." do tipo ".gettype($valor)."<br>";
?>