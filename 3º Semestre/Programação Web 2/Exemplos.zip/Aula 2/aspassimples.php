<?php 
$s1 = 'programação'; 
$s3 = 'a variável $s1 não será expandida';
echo $s3;
?>
