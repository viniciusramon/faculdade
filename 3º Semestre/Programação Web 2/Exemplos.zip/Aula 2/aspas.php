<?php
$nome = "Thiago";
$frase = "O aluno $nome cursa ADS";
echo $frase;
?>