<?php
$a = array("João","Maria","Pedro");
echo "<pre>";
print_r($a);
echo "</pre>";
echo "thiago";

?>