
<?php 
$decimal = 127; 
$decneg = -256; 
$octal = 077; 
$hexa = 0xF0A;
echo "Decimal: ".$decimal."<br>";
echo "Decimal Negativo: ".$decneg."<br>";
echo "Octal: ".$octal."<br>";
echo "Hexa: ".$hexa;
?>
