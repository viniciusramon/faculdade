
<?php 
$i = 10; //Inteiro 
$nome = "Walace"; // String 
$verdadeiro = TRUE; // Booleano 
$valor = 100.50; /// Ponto flutuante
echo "i: ".$i."<br>";
echo "Nome: ".$nome."<br>";
echo "Verdadeiro: ".$verdadeiro."<br>";
echo "Valor: ".$valor."<br>";
?>
