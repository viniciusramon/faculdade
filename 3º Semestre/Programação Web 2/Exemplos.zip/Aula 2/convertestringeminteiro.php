
<?php $s1 = "15x10"; 
$s2 = "x15"; 
$s3 = "1.25cx"; 
$s4 = "-1e10";
echo (int) $s1; 
echo "<br>";
echo (int) $s2;
echo "<br>";
echo (int) $s3;
echo "<br>"; 
echo (int) $s4;
?>
      
