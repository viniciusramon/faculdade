<?php 
$numero = 21474836476788999; 
echo gettype($numero) . "<br>"; 
$numero2 = $numero * 1000; 
echo gettype($numero2) . "<br>"; 
$numero3 = 1000; 
var_dump($numero*$numero3); //var_dump mostra informações da variável
?>
