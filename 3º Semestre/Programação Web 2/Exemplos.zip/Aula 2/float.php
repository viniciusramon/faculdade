<?php 
$n1 = 12.705;
$n2 = 1.23e10; 
$n3 = 2E-12;
echo "n1: ".$n1."<br>";
echo "n2: ".$n2."<br>";
echo "n3: ".$n3."<br>";
?>
