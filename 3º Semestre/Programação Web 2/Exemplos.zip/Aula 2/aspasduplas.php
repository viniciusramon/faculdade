<?php 
$s1 = 'programação'; 
$s3 = "a variável \"$s1\" será expandida";
echo $s3;
?>
