<?php

$f1 = 1.25;
$f2 = 1.7;
$f3 = -2.55;
$a = "10";
$i = (int)$a;
echo(int)$f1."<br>";
echo(int)$f2."<br>";
echo(int)$f3."<br>";
echo "Valor de a: $a do tipo ".gettype($a). "<br>";
echo "Valor de i: $i do tipo ".gettype($i). "<br>";

?>