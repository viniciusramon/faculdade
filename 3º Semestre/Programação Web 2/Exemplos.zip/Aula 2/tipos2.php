
<?php 
$i = 10; //Inteiro 
$nome = "Walace"; // String 
$verdadeiro = TRUE; // Booleano 
$valor = 100.50; /// Ponto flutuante
echo '$i é do Tipo ' . gettype($i) . "<br>"; 
echo '$nome é do Tipo ' . gettype($nome) . "<br>"; 
echo '$verdadeiro é do Tipo ' . gettype($verdadeiro) . "<br>"; 
echo '$valor é do Tipo ' . gettype($valor) . "<br>";
?>
