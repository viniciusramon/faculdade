<?php
    echo "Trabalhando com funções";
	função();
  	function função(){
 		echo "<br>";
  		for ($i=0; $i<10; $i++) {
 			echo "O Quadrado de " . $i  . " é   "   . ($i * $i);
 			echo "<br>";
  		}
 	}
?> 
