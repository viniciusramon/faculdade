<?php
	function quadrado($valor){
		echo "Quadrado de $valor é ".($valor*$valor);
	}
	quadrado(6);
?>