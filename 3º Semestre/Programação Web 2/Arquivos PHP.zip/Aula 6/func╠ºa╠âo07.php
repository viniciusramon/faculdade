<?php
function media($valor1, $valor2) {
	$m = ($valor1+$valor2)/2;
	return $m;
}
$valor1 = 9;
$valor2 = 8;
echo "A média dos valores é " . media($valor1, $valor2);
?> 
