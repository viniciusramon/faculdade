<?php 
$titulo = "PHP 5"; 
$titulo_final = $titulo . " - Guia do Programador";
echo "Titulo final: $titulo_final";
?>

