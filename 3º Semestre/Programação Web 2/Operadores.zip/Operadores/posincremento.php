<?php 
$v = 10;
$a = $v++;
$v++;
echo "$a :: $v";
?>
