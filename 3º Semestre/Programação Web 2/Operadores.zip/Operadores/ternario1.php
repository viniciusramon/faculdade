<?php 
$valor = 100;
$v = ($valor>=1000)?($valor*1.5):($valor*2.5);
echo "Valor de v: $v";
?>