<?php
$num1 = 20;
$num2 = 2;
echo "Soma: ".($num1+$num2)."<br>";
echo "Subtração: ".($num1 - $num2)."<br>";
echo "Multiplicação: ".($num1 * $num2)."<br>";
echo "Divisão: ".($num1 / $num2)."<br>";
echo "Módulo: ".($num1 % $num2)."<br>";
?>