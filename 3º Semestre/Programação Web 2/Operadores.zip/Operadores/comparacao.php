<?php
$num1 = 10;
$num2 = 20;
echo "Igualdade: ".($num1==$num2)."<br>";
echo "Idênticos: ".($num1===$num2)."<br>"; //se forem iguais e do mesmo tipo
echo "Diferente: ".($num1!=$num2)."<br>";
echo "Diferente: ".($num1<>$num2)."<br>";
echo "Não idênticos: ".($num1!==$num2)."<br>"; //não forem iguais e nem do mesmo tipo
echo "Menor: ".($num1<$num2)."<br>";
echo "Menor ou igual: ".($num1<=$num2)."<br>";
echo "Maior: ".($num1>$num2)."<br>";
echo "Maior ou igual: ".($num1>=$num2)."<br>";
?>