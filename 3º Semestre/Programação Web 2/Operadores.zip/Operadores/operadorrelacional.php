<?php 
$v = 10;
$b = 1001;
echo "Operador AND: ".(($v=10) AND ($b>1000))."<br>";
echo "Operador OR: ".(($v=10) OR ($b>1000))."<br>";
echo "Operador XOR: ".(($v=10) XOR ($b>1000))."<br>";
echo "Negação: ".(!($v==10))."<br>";
echo "Operador &&: ".(($v=10) && ($b>1000))."<br>";
echo "Operador ||: ".(($v=10) || ($b>1000))."<br>";
?>
