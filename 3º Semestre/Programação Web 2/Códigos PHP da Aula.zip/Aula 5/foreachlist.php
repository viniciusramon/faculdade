
<?php 
$_lista = [[1,2,3],[5,7,9],[15,120,123]]; 
foreach($_lista as list($_a,$_b,$_c)) 
{
	echo "{$_a},{$_b},{$_c}<br>"; 
}
?>
