<?php 
$arr = array(10,15,23,56,101,205); 
foreach($arr as $vlr) {
	echo "$vlr[2] <br>";
}
?>
