<?php
function valores($valor1="HTML", $valor2="PHP"){
	echo "O valor1 é $valor1 e o valor2 é $valor2" . echo "<br>";
}
valores();
valores("CSS", "C++");
valores("Java");
?>