<?php
function dobro($valor){
	return $valor * 2;
}
$a = dobro(10);
echo "Valor Dobrado: $a";
?>