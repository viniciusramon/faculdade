
<?php 
$arr = array(10,15,23,56,101,205); 
foreach($arr as $vlr) {
	echo "$vlr <br>";
} 
$arr_2 = array("um" => "one",
			   "dois" => "two", 
			   "três" => "three", 
			   "quatro" => "four", 
			   "cinco" => "five");
foreach($arr_2 as $chv => $vlr) { 
	echo "$chv = $vlr <br>";
} 
?>
