<?php
$array = array("um" => 1,
			   "dois" => 2,
			   "tres" => 3,
			   "quatro" => 4,
			   "cinco" => 5);
foreach($array as $chave => $valor){
	echo "$chave = $valor <br>";
}