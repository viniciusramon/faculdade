<?php
$lista= [[1,2,3],[5,6,7],[8,9,10]];
foreach($lista as list($a, $b, $c)){
	echo "{$a},{$b},{$c} <br>";
}
?>