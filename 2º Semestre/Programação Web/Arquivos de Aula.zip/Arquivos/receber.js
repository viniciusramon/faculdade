function mostraDados(){
	var usuario = document.cadastro.usuario.value;
	var senha = document.cadastro.senha.value;
	var msg = "Usuário: " +usuario+ " Senha: " +senha;
	alert(msg);
}