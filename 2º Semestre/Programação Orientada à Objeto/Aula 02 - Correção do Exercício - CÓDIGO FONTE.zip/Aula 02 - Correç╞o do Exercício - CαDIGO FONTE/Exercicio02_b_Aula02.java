public class Exercicio02_b_Aula02 {
    public static void main(String num[]) {
        int n = Integer.parseInt(num[0]) % 2;
        switch(n) {
            case 0:
                System.out.println("O número é par!");
                break;
            case 1:
                System.out.println("O número é ímpar!");
                break;
        }
    }
}
