public class Exercicio01_Aula02 {
    public static void main(String num[]) {
        int num1 = Integer.parseInt(num[0]);
        int num2 = Integer.parseInt(num[1]);
        int soma = num1 + num2;
        int subtracao = num1 - num2;
        float divisao = num1 / num2;
        int multiplicacao = num1 * num2;
        System.out.println("Resultados:");
        System.out.println("Soma = " + soma);
        System.out.println("Subtracao = " + subtracao);
        System.out.println("Divisao = " + divisao);
        System.out.println("Multiplicacao = " + multiplicacao);
    }
}