public class Exercicio03_Aula02 {
    public static void main(String param[]) {
        try {
            int num = Integer.parseInt(param[0]);
            if(num > 0)
                System.out.println("O número é positivo!");
            if(num < 0)
                System.out.println("O número é negativo!");
        } catch(NumberFormatException e) {
            System.out.println("Digite um número qualquer positivo ou negativo");
        } catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("Digite um parâmetro qualquer");
        }
    }
}