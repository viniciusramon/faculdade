public class Exercicio02_a_Aula02 {
    public static void main(String num[]) {
        int n = Integer.parseInt(num[0]);
        if(n % 2 == 0) 
            System.out.println("O número é par!");
        else
            System.out.println("O número é ímpar!");
    }
}