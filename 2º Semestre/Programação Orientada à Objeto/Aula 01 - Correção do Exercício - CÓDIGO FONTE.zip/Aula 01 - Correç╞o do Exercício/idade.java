public class idade {
    public static void main(String arg[]) {
        int ano = 2020;
        int idade = 43;
        int resultado = ano - idade;
        System.out.println("Seu ano de nascimento eh: " + resultado);
    }
}